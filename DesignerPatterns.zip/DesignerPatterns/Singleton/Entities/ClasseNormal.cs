﻿namespace Singleton.Entities
{
    public class ClasseNormal
    {
        public int variavelClasseNormal;
    }
}
